Jacob Southern

Run the program in any suitable python IDE.
You can see the pre-processed images in the folders.